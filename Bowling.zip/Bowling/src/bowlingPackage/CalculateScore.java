package bowlingPackage;

import java.util.ArrayList;
import java.util.List;

public class CalculateScore 
{
	private List<ArrayList<String>> listOfScoreRecords = new ArrayList<ArrayList<String>>();
	private int score = 0;
	
    public CalculateScore(List<ArrayList<String>> listOfScoreRecords) 
    {
        this.listOfScoreRecords = listOfScoreRecords;

    }
    
    
    public int getScore()
    {
    	
		// CALCULATE SCORE
		ArrayList<Integer> scoreBoard = new ArrayList<Integer>();
		int spareCheck = 0;
		for(int i = 0; i < listOfScoreRecords.size(); i++)
		{
			// Get our list
			var record = listOfScoreRecords.get(i);
			
			// Calc final tally
			if(listOfScoreRecords.size() == 11 && i == 9)
			{
				// Get the final record list
				var finalRecord = listOfScoreRecords.get(i + 1);
				
				if(record.size() > 1)
				{
					int primary = Integer.parseInt(record.get(0));
					int secondary = Integer.parseInt(record.get(1));
					spareCheck = primary + secondary;			
					
				}
				
				// Check if final record has double values
				if(finalRecord.size() > 1)
				{
					// Calculate
					int primary = Integer.parseInt(finalRecord.get(0));
					int secondary = Integer.parseInt(finalRecord.get(1));
					int recordPrimary = Integer.parseInt(record.get(0));
					score = recordPrimary + primary + secondary;
					
					// Add to scoreboard
					scoreBoard.add(score);
					break;
					
				}
				
				else
				{
					int primary = Integer.parseInt(finalRecord.get(0));
					score = spareCheck + primary;
					scoreBoard.add(score);
					break;
				}
				
			}// if
			
			else if(record.get(0).equals("10"))
			{
				int strikeIndex = i;
				var round = listOfScoreRecords.get(strikeIndex + 1);
				
				if(round.size() > 1)
				{
					int primary = Integer.parseInt(round.get(0));
					int secondary = Integer.parseInt(round.get(1));
					int recordPrimary = Integer.parseInt(record.get(0));
					score = recordPrimary + primary + secondary;
					
					scoreBoard.add(score);
				}
				else
				{
					
					var roundTwo = listOfScoreRecords.get(strikeIndex + 2);
					
					int primary = Integer.parseInt(round.get(0));
					int secondary = Integer.parseInt(roundTwo.get(0));
					int recordPrimary = Integer.parseInt(record.get(0));
					score = recordPrimary + primary + secondary;
					
					scoreBoard.add(score);
				}
				
				
			}
			
			// Logic for spare
			else if(record.size() > 1)
			{
				int primary = Integer.parseInt(record.get(0));
				int secondary = Integer.parseInt(record.get(1));
				int spareCheckLoop = primary + secondary;
				
				if(spareCheckLoop == 10)
				{
					var roundTwo = listOfScoreRecords.get(i + 1);
					int primaryRoundTwo = Integer.parseInt(roundTwo.get(0));
					score = 10 + primaryRoundTwo;
					scoreBoard.add(score);
				}
				
				else
				{
					score = spareCheckLoop;
					scoreBoard.add(score);
				}
			}
			
			
		}// for loop
		
		int finalScore = 0;
		for(int i : scoreBoard)
		{
			finalScore = finalScore + i;
		}
    	
    	return finalScore;
    	
    	
    }
    
    
}
