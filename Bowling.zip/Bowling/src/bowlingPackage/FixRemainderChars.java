package bowlingPackage;

import java.util.ArrayList;
import java.util.List;

public class FixRemainderChars 
{
	private List<ArrayList<String>> listOfScoreRecords = new ArrayList<ArrayList<String>>();
	
    public FixRemainderChars(List<ArrayList<String>> listOfScoreRecords) 
    {
        this.listOfScoreRecords = listOfScoreRecords;

    }
    
    public List<ArrayList<String>> fixChars()
    {
    	// Replace any chars left over with their proper values
    	for(var record : listOfScoreRecords)
    	{
    		if(record.size()> 1)
    		{
    			// Replace the left over misses 
    			if(record.get(1).equals("-"))
    			{
    				record.set(1, "0");
    			}
    					
    			// Spare check and math
    			else if(record.get(1).equals("/"))
    			{
    				// Convert the string val at the record at index 0
    				int primary = Integer.parseInt(record.get(0));
    						
    				// Get the value
    				int result = 10 - primary;
    						
    				// Update record
    				record.set(1, Integer.toString(result));
    			}
    					
    			else if(record.get(1).equals("X"))
    			{
    				if(record.get(0).equals("X"))
    				{
    					int addTen = 10;
    							
    					record.set(0, Integer.toString(addTen));
    					record.set(1, Integer.toString(addTen));
    				}
    			}
    					
    		}// if
    				
    		else if(record.get(0).equals("X"))
    		{
    			record.set(0, Integer.toString(10));
    		}
    		

    				
    	}// for loop
    	
		return listOfScoreRecords;
    			
    }
    
}

