package bowlingPackage;

import java.util.ArrayList;
import java.util.List;

public class GenerateListofListsRecords 
{
	// Create a list of lists to hold records for better/easier indexing
	private List<ArrayList<String>> listOfScoreRecords = new ArrayList<ArrayList<String>>();
	
	private ArrayList<Integer> listOfIndexes = new ArrayList<Integer>();
	private ArrayList<String> scoreInput = new ArrayList<String>();
	
    public GenerateListofListsRecords(ArrayList<Integer> listOfIndexes, ArrayList<String> scoreInput) 
    {
        this.listOfIndexes = listOfIndexes;
        this.scoreInput = scoreInput;

    }
    
    
    public List<ArrayList<String>> OrganizeRecords()
    {
    	
		// Start of record organization
		int count = 0;
		while (count < listOfIndexes.size())
		{
			
			// Create a temp list
			ArrayList<String> listTemp = new ArrayList<String>();
			
			if(count == 19)
			{
				
				if(listOfIndexes.size() > 20)
				{
					// Get the record
					String recordToAdd = scoreInput.get(listOfIndexes.get(count + 1));
					listTemp.add(recordToAdd);
					listOfScoreRecords.add(listTemp);
					break;
				}
				else
				{
					break;
				}
				
			}
			
			// If the 9/10th Index == "X", "STRIKE"
			if(count == listOfIndexes.size() - 2 && scoreInput.get(count).equals("X"))
			{	
				// Get primary rec to add
				String primary = scoreInput.get(listOfIndexes.get(count + 1));
				
				// Get the secondary rec to add
				String secondary = scoreInput.get(listOfIndexes.get(count + 1));
				
				listTemp.add(primary);
				listTemp.add(secondary);
				listOfScoreRecords.add(listTemp);
				break;
				
			}
			
			// Strike check
			else if(scoreInput.get(listOfIndexes.get(count)).equals("X"))
			{
				// Add X to listTemp list
				listTemp.add(scoreInput.get(listOfIndexes.get(count)));
				listOfScoreRecords.add(listTemp);
				count++;
			}
			
			// Miss check
			else if(scoreInput.get(listOfIndexes.get(count)).equals("-"))
			{	
				// Add a 0 for the miss
				listTemp.add("0");
				
				// Add the score after the miss
				String addRecord = scoreInput.get(listOfIndexes.get(count + 1));
				listTemp.add(addRecord);
				
				listOfScoreRecords.add(listTemp);
				
				// Add the index to use in replacement				
				int tempIndex = listOfIndexes.get(count + 1);
				// Replace
				scoreInput.set(listOfIndexes.indexOf(tempIndex), "");
				
				count++;

			}
			
			// If we run into an empty char, add 1 to count and keep looping
			else if(scoreInput.get(listOfIndexes.get(count)) == "")
			{
				count++;
			}
			
			// Handle all other test cases
			else
			{
				// Add the ball's num score
				listTemp.add(scoreInput.get(listOfIndexes.get(count)));
				
				// Get the next index after the first ball
				String appendRecord = scoreInput.get(listOfIndexes.get(count + 1));
				
				// Add it to the temp list
				listTemp.add(appendRecord);
				
				// Set the tempIndex to an idex of our list of indexes that is equal to the count
				// (count will be the current index of the iteration)
				int tempIndex = listOfIndexes.get(count + 1);
				
				// Change the element at our list of records to an empty char
				scoreInput.set(tempIndex, "");
				
				// Finally add the new temp list to the list of score records
				listOfScoreRecords.add(listTemp);
				
				count++;
			}
			
			
			
		}// While loop
		
		return listOfScoreRecords;
    	
    }
    
    
}
