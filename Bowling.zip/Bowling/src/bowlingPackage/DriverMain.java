package bowlingPackage;
import java.util.Scanner;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DriverMain 
{
	public static void main(String args[]) 
	{
		// Scanner to take user input
		Scanner output = new Scanner(System.in);
		
		// Get user Input
		// Assumes entry in 9-|9-|9-|9-|9-|9-|9-|9-|9-|9-|| type input
		System.out.print("Enter score: ");
		String scoreEntry = output.nextLine();
		scoreEntry = scoreEntry.replaceAll("[|]", "");
		
		// List to hold values from score input
		ArrayList<String> scoreInput = new ArrayList<String>();
		
		// Add records to a String List
		for(int i = 0; i < scoreEntry.length(); i++)
		{
			char charToAdd = scoreEntry.charAt(i);
			String stringCharToAdd = Character.toString(charToAdd);
			scoreInput.add(stringCharToAdd);
		}
        
        
		// Create a list of index for easier iteration and manipulation
		ArrayList<Integer> listOfIndexes = new ArrayList<Integer>();
		for(int i = 0; i < scoreInput.size(); i++)
		{
			listOfIndexes.add(i);
		}
		
		
		GenerateListofListsRecords organizedRecords = new GenerateListofListsRecords(listOfIndexes, scoreInput);
		var organizedList = organizedRecords.OrganizeRecords();
		
		// Fix the Characters we missed
		FixRemainderChars fixChars = new FixRemainderChars(organizedList);
		var listOfScoreRecordsFixed = fixChars.fixChars();
		
		// Calculate the final score of the game
		CalculateScore gameScore = new CalculateScore(listOfScoreRecordsFixed);
		var getScore = gameScore.getScore();
		System.out.println("Total Score: " + "" + getScore);
		
		// Close Scanner
		output.close();

		
	}// Main
        
}// Namesepace
        
